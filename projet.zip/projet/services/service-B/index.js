const http = require("http");

const server = http.createServer((req, res) => {
  const traceId = req.headers["x-trace-id"] || "no-trace";
  const clientIp = req.headers["x-real-ip"] || "unknown";

  console.log(JSON.stringify({
    service: "service-b",
    trace_id: traceId,
    client_ip: clientIp,
    url_received: req.url,   // URL réécrite par la gateway
    timestamp: new Date().toISOString()
  }));

  if (req.url.startsWith("/v2/catalog")) {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({
      service: "Products Service",
      trace_id: traceId,
      data: [
        { id: 101, name: "Laptop",  price: 999  },
        { id: 102, name: "Mouse",   price: 29   },
        { id: 103, name: "Clavier", price: 49   }
      ]
    }));
  } else {
    res.writeHead(404, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Not found", url: req.url }));
  }
});

server.listen(3000, () => {
  console.log("Service-B (Products) démarré sur le port 3000");
});

const http = require("http");
const crypto = require("crypto");

// Cl� secr�te pour signer les tokens JWT
const SECRET = "mon-secret-jwt-2026";

// Base de donn�es utilisateurs (simulation)
const users = {
  Ali: "password123",
  Ahmed: "password456"
};

// Fonction pour cr�er un token JWT simple
function createToken(username) {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64");
  const payload = Buffer.from(JSON.stringify({
    user: username,
    exp: Date.now() + 3600000  // expire dans 1 heure
  })).toString("base64");
  const signature = crypto.createHmac("sha256", SECRET).update(header + "." + payload).digest("base64");
  return header + "." + payload + "." + signature;
}

// Fonction pour v�rifier un token JWT
function verifyToken(token) {
  try {
    const [header, payload, signature] = token.split(".");
    const expectedSig = crypto.createHmac("sha256", SECRET).update(header + "." + payload).digest("base64");
    if (signature !== expectedSig) return null;
    const data = JSON.parse(Buffer.from(payload, "base64").toString());
    if (data.exp < Date.now()) return null;
    return data;
  } catch {
    return null;
  }
}

const server = http.createServer((req, res) => {
  let body = "";
  req.on("data", chunk => body += chunk);
  req.on("end", () => {

    // POST /auth/login ? g�n�re un token
    if (req.method === "POST" && req.url === "/auth/login") {
      const { username, password } = JSON.parse(body);
      if (users[username] && users[username] === password) {
        const token = createToken(username);
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ token, message: "Connexion r�ussie !" }));
      } else {
        res.writeHead(401, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Identifiants invalides" }));
      }

    // GET /auth/verify ? v�rifie un token
    } else if (req.method === "GET" && req.url.startsWith("/auth/verify")) {
      const authHeader = req.headers["authorization"] || "";
      const token = authHeader.replace("Bearer ", "");
      const data = verifyToken(token);
      if (data) {
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ valid: true, user: data.user }));
      } else {
        res.writeHead(401, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ valid: false, error: "Token invalide" }));
      }
    } else {
      res.writeHead(404);
      res.end(JSON.stringify({ error: "Route non trouv�e" }));
    }
  });
});

server.listen(3000, () => {
  console.log("Auth-Service d�marr� sur le port 3000");
});

from flask import Flask, jsonify, request, render_template_string
from flask_cors import CORS
import jwt

app = Flask(__name__)
CORS(app)

SECRET_KEY = "super-secret-jwt-key"

users_list = [
    {"id": 1, "name": "safinase"},
    {"id": 2, "name": "houssein"}
]

def verify_token():
    token = request.args.get("token")

    if not token:
        return False, {"message": "Token manquant"}

    try:
        decoded = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return True, decoded
    except jwt.ExpiredSignatureError:
        return False, {"message": "Token expiré"}
    except jwt.InvalidTokenError:
        return False, {"message": "Token invalide"}

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des utilisateurs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

    <style>
        :root {
          --bg-1: #07111f;
          --bg-2: #111c35;
          --bg-3: #1d1b4f;
          --card-bg: rgba(255, 255, 255, 0.10);
          --card-border: rgba(255, 255, 255, 0.16);
          --white-soft: rgba(255,255,255,0.75);
          --primary: #8b5cf6;
          --primary-2: #06b6d4;
          --accent: #ec4899;
          --success: #10b981;
          --danger: #ef4444;
          --text: #f8fafc;
          --muted: #cbd5e1;
          --shadow-lg: 0 30px 60px rgba(0,0,0,0.35);
          --shadow-md: 0 12px 30px rgba(0,0,0,0.20);
          --transition: 0.28s ease;
        }

        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        body {
          font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
          min-height: 100vh;
          background:
            radial-gradient(circle at top left, rgba(139,92,246,0.22), transparent 30%),
            radial-gradient(circle at bottom right, rgba(6,182,212,0.22), transparent 30%),
            linear-gradient(135deg, var(--bg-1), var(--bg-2), var(--bg-3));
          color: var(--text);
          padding: 28px;
        }

        .page {
          max-width: 1200px;
          margin: 0 auto;
        }

        .topbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
          margin-bottom: 24px;
          flex-wrap: wrap;
        }

        .title-box {
          flex: 1;
          background: linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0.05));
          border: 1px solid var(--card-border);
          backdrop-filter: blur(16px);
          border-radius: 24px;
          box-shadow: var(--shadow-lg);
          padding: 24px;
        }

        .title-box h1 {
          font-size: 2rem;
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 8px;
        }

        .title-box p {
          color: var(--muted);
        }

        .actions-top {
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
        }

        .btn-top {
          border: none;
          border-radius: 14px;
          cursor: pointer;
          font-weight: 700;
          padding: 14px 18px;
          color: white;
          transition: var(--transition);
          box-shadow: var(--shadow-md);
        }

        .btn-top:hover {
          transform: translateY(-2px);
        }

        .btn-back {
          background: linear-gradient(135deg, #8b5cf6, #06b6d4);
        }

        .btn-logout {
          background: linear-gradient(135deg, #ef4444, #dc2626);
        }

        .grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 22px;
        }

        .card {
          background: linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0.05));
          border: 1px solid var(--card-border);
          border-radius: 24px;
          padding: 24px;
          backdrop-filter: blur(16px);
          box-shadow: var(--shadow-md);
          transition: var(--transition);
        }

        .card:hover {
          transform: translateY(-6px);
        }

        .icon-box {
          width: 62px;
          height: 62px;
          border-radius: 18px;
          background: linear-gradient(135deg, #8b5cf6, #06b6d4);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.4rem;
          margin-bottom: 18px;
          box-shadow: 0 10px 24px rgba(99,102,241,0.28);
        }

        .mini-label {
          color: var(--muted);
          font-size: 0.95rem;
          margin-bottom: 6px;
        }

        .mini-value {
          font-size: 1.25rem;
          font-weight: 700;
          margin-bottom: 14px;
        }

        .chip {
          display: inline-block;
          padding: 8px 12px;
          border-radius: 999px;
          background: rgba(6,182,212,0.12);
          border: 1px solid rgba(6,182,212,0.24);
          color: #bae6fd;
          font-size: 0.85rem;
          font-weight: 600;
        }

        @media (max-width: 640px) {
          body {
            padding: 18px;
          }

          .title-box h1 {
            font-size: 1.5rem;
          }

          .actions-top {
            width: 100%;
          }

          .btn-top {
            width: 100%;
          }
        }
    </style>
</head>
<body>
    <div class="page">
        <div class="topbar">
            <div class="title-box">
                <h1><i class="fas fa-users"></i> Liste des utilisateurs</h1>
                <p>Interface sécurisée des utilisateurs, dans le même style que le login.</p>
            </div>

            <div class="actions-top">
                <button class="btn-top btn-back" onclick="goDashboard()">
                    <i class="fas fa-arrow-left"></i> Retour
                </button>

                <button class="btn-top btn-logout" onclick="logout()">
                    <i class="fas fa-arrow-right-from-bracket"></i> Déconnexion
                </button>
            </div>
        </div>

        <div class="grid">
            {% for user in users %}
            <div class="card">
                <div class="icon-box">
                    <i class="fas fa-user"></i>
                </div>

                <div class="mini-label">Identifiant</div>
                <div class="mini-value">#{{ user.id }}</div>

                <div class="mini-label">Nom</div>
                <div class="mini-value">{{ user.name }}</div>

                <span class="chip">Utilisateur actif</span>
            </div>
            {% endfor %}
        </div>
    </div>

    <script>
        function getToken() {
            const params = new URLSearchParams(window.location.search);
            return params.get("token");
        }

        function goDashboard() {
            const token = getToken();

            if (token) {
                window.location.href = "/?token=" + encodeURIComponent(token);
            } else {
                window.location.href = "/";
            }
        }

        function logout() {
            window.location.href = "/";
        }
    </script>
</body>
</html>
"""

@app.route("/")
def home():
    ok, res = verify_token()
    if not ok:
        return jsonify(res), 401

    return jsonify({
        "service": "users",
        "users": users_list
    })

@app.route("/users")
def users():
    ok, res = verify_token()
    if not ok:
        return jsonify(res), 401

    return render_template_string(HTML_TEMPLATE, users=users_list)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=True)
from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import jwt
import datetime

app = Flask(__name__)
CORS(app)

SECRET_KEY = "super-secret-jwt-key"
JWT_ISSUER = "app-client"
TOKEN_DURATION_MINUTES = 15

LOGIN_HTML = """
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login Zero Trust</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

  <style>
    :root {
      --bg-1: #07111f;
      --bg-2: #111c35;
      --bg-3: #1d1b4f;
      --card-bg: rgba(255, 255, 255, 0.10);
      --card-border: rgba(255, 255, 255, 0.16);
      --white-soft: rgba(255,255,255,0.75);
      --primary: #8b5cf6;
      --primary-2: #06b6d4;
      --accent: #ec4899;
      --success: #10b981;
      --danger: #ef4444;
      --text: #f8fafc;
      --muted: #cbd5e1;
      --input-bg: rgba(255,255,255,0.07);
      --input-border: rgba(255,255,255,0.12);
      --shadow-lg: 0 30px 60px rgba(0,0,0,0.35);
      --shadow-md: 0 12px 30px rgba(0,0,0,0.20);
      --radius-xl: 28px;
      --radius-lg: 18px;
      --radius-md: 14px;
      --transition: 0.28s ease;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body { min-height: 100%; }

    body {
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
      background:
        radial-gradient(circle at top left, rgba(139,92,246,0.22), transparent 30%),
        radial-gradient(circle at bottom right, rgba(6,182,212,0.22), transparent 30%),
        linear-gradient(135deg, var(--bg-1), var(--bg-2), var(--bg-3));
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
      color: var(--text);
      overflow-x: hidden;
      position: relative;
    }

    .background-blur {
      position: fixed;
      inset: 0;
      z-index: 0;
      overflow: hidden;
      pointer-events: none;
    }

    .orb {
      position: absolute;
      border-radius: 50%;
      filter: blur(85px);
      opacity: 0.42;
      animation: floatOrb 12s ease-in-out infinite;
    }

    .orb-1 { width: 280px; height: 280px; background: #8b5cf6; top: 4%; left: 6%; }
    .orb-2 { width: 300px; height: 300px; background: #06b6d4; right: 8%; bottom: 8%; animation-delay: 2s; }
    .orb-3 { width: 200px; height: 200px; background: #ec4899; left: 18%; bottom: 15%; animation-delay: 4s; }

    .grid-overlay {
      position: fixed;
      inset: 0;
      z-index: 0;
      background-image:
        linear-gradient(rgba(255,255,255,0.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,0.035) 1px, transparent 1px);
      background-size: 28px 28px;
      mask-image: radial-gradient(circle at center, black 35%, transparent 90%);
      pointer-events: none;
    }

    @keyframes floatOrb {
      0%, 100% { transform: translateY(0px) translateX(0px) scale(1); }
      50% { transform: translateY(-18px) translateX(10px) scale(1.06); }
    }

    .container {
      position: relative;
      z-index: 1;
      width: 100%;
      max-width: 560px;
      background: linear-gradient(180deg, rgba(255,255,255,0.12), rgba(255,255,255,0.08));
      border: 1px solid var(--card-border);
      backdrop-filter: blur(22px);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-lg);
      overflow: hidden;
    }

    .top-line {
      height: 4px;
      background: linear-gradient(90deg, var(--primary), var(--primary-2), var(--accent));
      background-size: 200% 100%;
      animation: shimmer 5s linear infinite;
    }

    @keyframes shimmer {
      0% { background-position: 0% 50%; }
      100% { background-position: 200% 50%; }
    }

    .header {
      text-align: center;
      padding: 34px 26px 22px;
      background:
        linear-gradient(135deg, rgba(139,92,246,0.20), rgba(6,182,212,0.10)),
        rgba(255,255,255,0.03);
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }

    .badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 8px 14px;
      border-radius: 999px;
      font-size: 0.82rem;
      color: #e9d5ff;
      background: rgba(139,92,246,0.14);
      border: 1px solid rgba(139,92,246,0.24);
      margin-bottom: 16px;
    }

    .header h1 { font-size: 2rem; margin-bottom: 10px; }
    .header p { color: var(--muted); font-size: 0.98rem; line-height: 1.6; max-width: 420px; margin: 0 auto; }

    .content { padding: 28px; }
    .form-group { margin-bottom: 18px; }

    .form-label {
      display: flex;
      align-items: center;
      gap: 8px;
      font-weight: 600;
      margin-bottom: 9px;
      color: #e2e8f0;
      font-size: 0.95rem;
    }

    .input-wrapper { position: relative; }

    .input-wrapper > i {
      position: absolute;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      color: #94a3b8;
      z-index: 2;
    }

    input {
      width: 100%;
      padding: 15px 48px 15px 48px;
      border-radius: 16px;
      border: 1px solid var(--input-border);
      background: linear-gradient(180deg, rgba(255,255,255,0.09), rgba(255,255,255,0.05));
      color: white;
      outline: none;
      font-size: 1rem;
    }

    input::placeholder { color: #94a3b8; }

    .toggle-password {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
      border: none;
      background: transparent;
      color: #b6c2d1;
      cursor: pointer;
      width: 34px;
      height: 34px;
      border-radius: 10px;
      z-index: 2;
    }

    .row-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin: 6px 0 18px;
      color: var(--muted);
      font-size: 0.9rem;
    }

    .session-tag {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      border-radius: 999px;
      border: 1px solid rgba(255,255,255,0.10);
      background: rgba(255,255,255,0.05);
    }

    .btn-login, .btn-action, .btn-logout {
      border: none;
      border-radius: 16px;
      cursor: pointer;
      font-weight: 700;
      position: relative;
      overflow: hidden;
    }

    .btn-login {
      width: 100%;
      padding: 16px;
      font-size: 1rem;
      color: white;
      background: linear-gradient(135deg, #8b5cf6, #06b6d4);
      box-shadow: 0 16px 30px rgba(99,102,241,0.28);
      margin-top: 6px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }

    .btn-login.loading { pointer-events: none; opacity: 0.95; }
    .btn-login.loading .btn-text { opacity: 0; }

    .spinner {
      width: 20px;
      height: 20px;
      border: 2.8px solid rgba(255,255,255,0.28);
      border-top-color: white;
      border-radius: 50%;
      animation: spin 0.9s linear infinite;
      display: none;
      position: absolute;
    }

    .btn-login.loading .spinner { display: inline-block; }

    @keyframes spin { to { transform: rotate(360deg); } }

    .actions {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 14px;
      margin-bottom: 18px;
    }

    .btn-action {
      min-height: 108px;
      padding: 18px;
      color: white;
      background: linear-gradient(135deg, rgba(139,92,246,0.95), rgba(6,182,212,0.88));
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 10px;
      font-size: 1rem;
      box-shadow: var(--shadow-md);
    }

    .btn-logout {
      width: 100%;
      padding: 15px;
      background: linear-gradient(135deg, #ef4444, #dc2626);
      color: white;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }

    #status {
      margin-top: 18px;
      padding: 14px 16px;
      border-radius: 16px;
      font-weight: 600;
      text-align: center;
      display: none;
    }

    .status-success {
      display: block !important;
      background: rgba(16,185,129,0.15);
      color: #a7f3d0;
      border: 1px solid rgba(16,185,129,0.35);
    }

    .status-error {
      display: block !important;
      background: rgba(239,68,68,0.15);
      color: #fecaca;
      border: 1px solid rgba(239,68,68,0.35);
    }

    .status-info {
      display: block !important;
      background: rgba(6,182,212,0.12);
      color: #bae6fd;
      border: 1px solid rgba(6,182,212,0.30);
    }

    #result {
      margin-top: 18px;
      background: linear-gradient(180deg, rgba(255,255,255,0.07), rgba(255,255,255,0.05));
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 18px;
      padding: 18px;
      min-height: 76px;
      color: #e2e8f0;
      overflow: auto;
    }

    .welcome-box {
      text-align: center;
      color: #cbd5e1;
      line-height: 1.75;
    }

    .welcome-box i {
      font-size: 1.6rem;
      margin-bottom: 10px;
      color: #c4b5fd;
    }

    pre {
      white-space: pre-wrap;
      word-wrap: break-word;
      margin: 0;
      font-family: Consolas, "Courier New", monospace;
      font-size: 0.92rem;
      line-height: 1.65;
    }

    .footer-note {
      margin-top: 16px;
      text-align: center;
      color: var(--white-soft);
      font-size: 0.8rem;
      opacity: 0.88;
    }

    .hidden { display: none !important; }

    @media (max-width: 560px) {
      .actions { grid-template-columns: 1fr; }
      .row-meta { flex-direction: column; align-items: flex-start; }
      .content { padding: 22px; }
    }
  </style>
</head>
<body>
  <div class="background-blur">
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
  </div>
  <div class="grid-overlay"></div>

  <div class="container">
    <div class="top-line"></div>

    <div class="header">
      <div class="badge">
        <i class="fas fa-sparkles"></i>
        <span>Interface Zero Trust sécurisée</span>
      </div>

      <h1>Authentification</h1>
      <p>Connexion sécurisée aux services utilisateurs et produits avec une interface moderne, fluide et dynamique.</p>
    </div>

    <div class="content">
      <div id="loginSection">
        <div class="form-group">
          <label class="form-label" for="username">
            <i class="fas fa-user"></i>
            Nom d'utilisateur
          </label>
          <div class="input-wrapper">
            <i class="fas fa-user"></i>
            <input id="username" type="text" placeholder="Entrez votre nom d'utilisateur" autocomplete="off">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="password">
            <i class="fas fa-lock"></i>
            Mot de passe
          </label>
          <div class="input-wrapper">
            <i class="fas fa-lock"></i>
            <input id="password" type="password" placeholder="Entrez votre mot de passe" autocomplete="off">
            <button type="button" class="toggle-password" onclick="togglePassword()" aria-label="Afficher ou masquer le mot de passe">
              <i id="togglePasswordIcon" class="fas fa-eye"></i>
            </button>
          </div>
        </div>

        <div class="row-meta">
          <div class="session-tag">
            <i class="fas fa-circle-check"></i>
            <span>Session protégée</span>
          </div>
          <div class="hint">Navigation sécurisée entre dashboard, users et products.</div>
        </div>

        <button id="loginBtn" class="btn-login" onclick="login()">
          <span class="spinner"></span>
          <span class="btn-text">
            <i class="fas fa-right-to-bracket"></i> Se connecter
          </span>
        </button>
      </div>

      <div id="dashboardSection" class="hidden">
        <div class="actions">
          <button class="btn-action" onclick="getUsers()">
            <i class="fas fa-users"></i>
            <span>
              Users
              <small>Accéder à la liste des utilisateurs</small>
            </span>
          </button>

          <button class="btn-action" onclick="getProducts()">
            <i class="fas fa-box-open"></i>
            <span>
              Products
              <small>Accéder à la liste des produits</small>
            </span>
          </button>
        </div>

        <button class="btn-logout" onclick="logout()">
          <i class="fas fa-arrow-right-from-bracket"></i>
          Se déconnecter
        </button>
      </div>

      <div id="status"></div>

      <div id="result">
        <div class="welcome-box">
          <i class="fas fa-lock"></i>
          <p>Bienvenue. Connecte-toi pour accéder aux services.</p>
        </div>
      </div>

      <div class="footer-note">
        Zero Trust Access • Dashboard central
      </div>
    </div>
  </div>

  <script>
    const API_BASE = "";
    const SESSION_KEY = "token";

    const params = new URLSearchParams(window.location.search);
    const tokenFromUrl = params.get("token");

    if (tokenFromUrl) {
      sessionStorage.setItem(SESSION_KEY, tokenFromUrl);
    }

    function setStatus(message, type = "error") {
      const statusEl = document.getElementById("status");
      statusEl.textContent = message;
      statusEl.className = "";

      if (type === "success") {
        statusEl.classList.add("status-success");
      } else if (type === "info") {
        statusEl.classList.add("status-info");
      } else {
        statusEl.classList.add("status-error");
      }
    }

    function setResult(data) {
      const resultEl = document.getElementById("result");

      if (typeof data === "string") {
        resultEl.innerHTML = `<pre>${data}</pre>`;
        return;
      }

      resultEl.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
    }

    function showWelcome() {
      document.getElementById("result").innerHTML = `
        <div class="welcome-box">
          <i class="fas fa-lock"></i>
          <p>Bienvenue. Connecte-toi pour accéder aux services sécurisés.</p>
        </div>
      `;
    }

    function showDashboard() {
      document.getElementById("loginSection").classList.add("hidden");
      document.getElementById("dashboardSection").classList.remove("hidden");
    }

    function showLogin() {
      document.getElementById("loginSection").classList.remove("hidden");
      document.getElementById("dashboardSection").classList.add("hidden");
    }

    function setLoginLoading(isLoading) {
      const btn = document.getElementById("loginBtn");
      btn.classList.toggle("loading", isLoading);
    }

    function togglePassword() {
      const passwordInput = document.getElementById("password");
      const icon = document.getElementById("togglePasswordIcon");

      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        icon.className = "fas fa-eye-slash";
      } else {
        passwordInput.type = "password";
        icon.className = "fas fa-eye";
      }
    }

    async function login() {
      const username = document.getElementById("username").value.trim();
      const password = document.getElementById("password").value.trim();

      if (!username || !password) {
        setStatus("Veuillez remplir tous les champs", "error");
        setResult("Nom d'utilisateur ou mot de passe manquant.");
        return;
      }

      setLoginLoading(true);

      try {
        const response = await fetch("/auth/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            username: username,
            password: password
          })
        });

        const data = await response.json();

        if (!response.ok) {
          setStatus("Échec de connexion", "error");
          setResult(data);
          return;
        }

        sessionStorage.setItem(SESSION_KEY, data.token);

        setStatus("Connexion réussie", "success");
        setResult({
          message: "Authentification réussie",
          username: username,
          token: data.token
        });

        showDashboard();

      } catch (error) {
        setStatus("Erreur réseau", "error");
        setResult(error.message);
      } finally {
        setLoginLoading(false);
      }
    }

    function getUsers() {
      const token = sessionStorage.getItem(SESSION_KEY);

      if (!token) {
        setStatus("Token introuvable", "error");
        setResult("Veuillez vous reconnecter.");
        showLogin();
        return;
      }

      window.location.href = "/api/users?token=" + encodeURIComponent(token);
    }

    function getProducts() {
      const token = sessionStorage.getItem(SESSION_KEY);

      if (!token) {
        setStatus("Token introuvable", "error");
        setResult("Veuillez vous reconnecter.");
        showLogin();
        return;
      }

      window.location.href = "/api/products?token=" + encodeURIComponent(token);
    }

    function logout() {
      sessionStorage.removeItem(SESSION_KEY);
      setStatus("Déconnecté", "info");
      setResult("Session fermée.");
      showLogin();
      showWelcome();
      document.getElementById("password").value = "";
      document.getElementById("username").value = "";
      window.history.replaceState({}, document.title, "/");
    }

    document.getElementById("password").addEventListener("keydown", function(event) {
      if (event.key === "Enter") {
        login();
      }
    });

    document.getElementById("username").addEventListener("keydown", function(event) {
      if (event.key === "Enter") {
        login();
      }
    });

    window.onload = function () {
      const token = sessionStorage.getItem(SESSION_KEY);

      if (token) {
        showDashboard();
        setStatus("Session active", "success");
      } else {
        showLogin();
        showWelcome();
      }
    };
  </script>
</body>
</html>
"""

@app.route("/")
def home():
    return render_template_string(LOGIN_HTML)

@app.route("/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}

    username = (data.get("username") or "").strip()
    password = (data.get("password") or "").strip()

    if username == "admin" and password == "admin123":
        now = datetime.datetime.utcnow()
        payload = {
            "sub": username,
            "iss": JWT_ISSUER,
            "iat": now,
            "exp": now + datetime.timedelta(minutes=TOKEN_DURATION_MINUTES)
        }

        token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")

        return jsonify({
            "message": "Login réussi",
            "token": token,
            "expires_in_minutes": TOKEN_DURATION_MINUTES
        })

    return jsonify({"message": "Identifiants invalides"}), 401

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
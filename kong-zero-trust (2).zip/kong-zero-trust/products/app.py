from flask import Flask, jsonify, request, render_template_string
from flask_cors import CORS
import jwt

app = Flask(__name__)
CORS(app)

SECRET_KEY = "super-secret-jwt-key"

products_list = [
    {"id": 1, "name": "Laptop HP"},
    {"id": 2, "name": "Honor"}
]

def verify_token():
    token = request.args.get("token")

    if not token:
        return False, {"message": "Token manquant"}

    try:
        decoded = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return True, decoded
    except jwt.ExpiredSignatureError:
        return False, {"message": "Token expiré"}
    except jwt.InvalidTokenError:
        return False, {"message": "Token invalide"}

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Produits</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

<style>
:root {
  --bg-1: #07111f;
  --bg-2: #111c35;
  --bg-3: #1d1b4f;
  --card-bg: rgba(255,255,255,0.10);
  --card-border: rgba(255,255,255,0.16);
  --primary: #8b5cf6;
  --primary-2: #06b6d4;
  --danger: #ef4444;
  --text: #f8fafc;
  --muted: #cbd5e1;
  --shadow-lg: 0 30px 60px rgba(0,0,0,0.35);
  --shadow-md: 0 12px 30px rgba(0,0,0,0.20);
}

*{margin:0;padding:0;box-sizing:border-box;}

body{
  font-family:Segoe UI;
  min-height:100vh;
  background:
    radial-gradient(circle at top left, rgba(139,92,246,0.22), transparent),
    radial-gradient(circle at bottom right, rgba(6,182,212,0.22), transparent),
    linear-gradient(135deg,var(--bg-1),var(--bg-2),var(--bg-3));
  color:var(--text);
  padding:30px;
}

.page{max-width:1200px;margin:auto;}

.topbar{
  display:flex;
  justify-content:space-between;
  align-items:center;
  margin-bottom:25px;
  flex-wrap:wrap;
  gap: 14px;
}

.title{
  background:var(--card-bg);
  border:1px solid var(--card-border);
  padding:20px;
  border-radius:20px;
  backdrop-filter:blur(14px);
  box-shadow:var(--shadow-lg);
  flex: 1;
  min-width: 280px;
}

.title h1{
  font-size:1.8rem;
  margin-bottom:5px;
}

.title p{color:var(--muted);}

.actions{
  display:flex;
  gap:10px;
  flex-wrap: wrap;
}

.btn{
  padding:12px 18px;
  border:none;
  border-radius:12px;
  cursor:pointer;
  font-weight:bold;
  color:white;
  transition:.2s;
}

.btn:hover{transform:translateY(-2px);}

.btn-back{background:linear-gradient(135deg,#8b5cf6,#06b6d4);}
.btn-logout{background:linear-gradient(135deg,#ef4444,#dc2626);}

.grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
  gap:20px;
}

.card{
  background:var(--card-bg);
  border:1px solid var(--card-border);
  border-radius:20px;
  padding:20px;
  backdrop-filter:blur(12px);
  box-shadow:var(--shadow-md);
}

.icon{
  width:60px;
  height:60px;
  border-radius:15px;
  background:linear-gradient(135deg,#8b5cf6,#06b6d4);
  display:flex;
  align-items:center;
  justify-content:center;
  margin-bottom:15px;
}

.label{color:var(--muted);font-size:.9rem;}
.value{font-weight:bold;margin-bottom:10px;font-size: 1.2rem;}

@media (max-width: 640px) {
  body { padding: 18px; }
  .actions { width: 100%; }
  .btn { width: 100%; }
}
</style>
</head>

<body>

<div class="page">

<div class="topbar">
  <div class="title">
    <h1><i class="fas fa-box"></i> Produits</h1>
    <p>Interface sécurisée des produits</p>
  </div>

  <div class="actions">
    <button class="btn btn-back" onclick="goDashboard()">
      <i class="fas fa-arrow-left"></i> Retour
    </button>

    <button class="btn btn-logout" onclick="logout()">
      <i class="fas fa-sign-out-alt"></i> Déconnexion
    </button>
  </div>
</div>

<div class="grid">
{% for p in products %}
<div class="card">
  <div class="icon"><i class="fas fa-box"></i></div>
  <div class="label">ID</div>
  <div class="value">#{{p.id}}</div>
  <div class="label">Nom</div>
  <div class="value">{{p.name}}</div>
</div>
{% endfor %}
</div>

</div>

<script>
function getToken(){
  const params = new URLSearchParams(window.location.search);
  return params.get("token");
}

function goDashboard(){
  const token = getToken();
  if(token){
    window.location.href = "/?token=" + encodeURIComponent(token);
  }else{
    window.location.href = "/";
  }
}

function logout(){
  window.location.href = "/";
}
</script>

</body>
</html>
"""

@app.route("/")
def home():
    ok, res = verify_token()
    if not ok:
        return jsonify(res), 401

    return jsonify({
        "service": "products",
        "products": products_list
    })

@app.route("/products")
def products():
    ok, res = verify_token()
    if not ok:
        return jsonify(res), 401

    return render_template_string(HTML_TEMPLATE, products=products_list)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002, debug=True)
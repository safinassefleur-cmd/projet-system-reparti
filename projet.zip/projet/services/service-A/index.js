const http = require("http");

const server = http.createServer((req, res) => {
  // Récupère le trace-id transmis par la Gateway
  const traceId = req.headers["x-trace-id"] || "no-trace";
  const clientIp = req.headers["x-real-ip"] || "unknown";

  console.log(JSON.stringify({
    service: "service-a",
    trace_id: traceId,
    client_ip: clientIp,
    url_received: req.url,   // URL réécrite par la gateway
    timestamp: new Date().toISOString()
  }));

  // Répondre selon l'URL réécrite reçue
  if (req.url.startsWith("/internal/v1/list")) {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({
      service: "Users Service",
      trace_id: traceId,
      data: [
        { id: 1, name: "Ali", role: "admin" },
        { id: 2, name: "Ahmed",   role: "user"  }
      ]
    }));
  } else {
    res.writeHead(404, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Not found", url: req.url }));
  }
});

server.listen(3000, () => {
  console.log("Service-A (Users) démarré sur le port 3000");
});

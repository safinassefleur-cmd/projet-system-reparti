# Projet 6 — API Gateway & Zero-Trust
## Focus : Périmètre et Proxying avec Docker + Nginx

---

## 📁 Structure du projet

```
projet6/
├── docker-compose.yml          ← Orchestration de tous les services
├── gateway/
│   └── nginx/
│       └── nginx.conf          ← Config Nginx (Gateway)
├── services/
│   ├── service-a/              ← Microservice Users
│   │   ├── index.js
│   │   └── Dockerfile
│   └── service-b/              ← Microservice Products
│       ├── index.js
│       └── Dockerfile
└── logs/                       ← Logs JSON générés automatiquement
```

---

## 🚀 Lancer le projet

```bash
# 1. Construire et démarrer tous les conteneurs
docker-compose up --build

# 2. Tester depuis un autre terminal
curl http://localhost/             # Accueil de la Gateway
curl http://localhost/api/users    # → redirigé vers service-a:/internal/v1/list
curl http://localhost/api/products # → redirigé vers service-b:/v2/catalog
```

---

## ❓ Réponses aux questions du projet

### 1. Architecture de routage — Reverse Proxy + URL Rewriting

La Gateway fait les **deux** :
- **Reverse Proxy** : elle reçoit les requêtes et les transfère aux services backend
- **URL Rewriting** : elle transforme l'URL avant de transmettre

| URL appelée par le client | URL reçue par le service |
|---------------------------|--------------------------|
| `GET /api/users`          | `GET /internal/v1/list`  |
| `GET /api/products`       | `GET /v2/catalog`        |

Le client ne connaît **jamais** la structure interne des services.

---

### 2. Attaque de surface — Masquer les en-têtes HTTP

Dans `nginx.conf` :
```nginx
server_tokens off;              # Cache la version Nginx
proxy_hide_header X-Powered-By; # Cache "Express", "Node.js"...
proxy_hide_header Server;       # Cache l'en-tête Server du backend
add_header Server "API-Gateway";# Remplace par un nom neutre
```

**Avant (sans protection)** :
```
Server: nginx/1.18.0
X-Powered-By: Express
```

**Après (avec protection)** :
```
Server: API-Gateway
```

---

### 3. Stratégie de Logs — Tracer une requête de bout en bout

Chaque requête reçoit un **trace-id unique** (`$request_id` dans Nginx).
Ce trace-id est transmis à chaque service backend via l'en-tête `X-Trace-Id`.

**Exemple de log JSON généré** :
```json
{
  "timestamp": "2026-03-03T09:54:44+00:00",
  "trace_id": "abc123xyz",
  "client_ip": "192.168.1.10",
  "method": "GET",
  "original_uri": "/api/users",
  "rewritten_uri": "/internal/v1/list",
  "backend": "172.20.0.3:3000",
  "status": 200,
  "duration_ms": "0.002"
}
```

Les logs sont sauvegardés dans le dossier `./logs/access.log`.

```bash
# Lire les logs en temps réel
tail -f logs/access.log | python3 -m json.tool
```

---

## 🛑 Arrêter le projet

```bash
docker-compose down
```
